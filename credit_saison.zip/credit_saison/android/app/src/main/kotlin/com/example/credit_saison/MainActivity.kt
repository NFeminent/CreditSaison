package com.example.credit_saison

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
